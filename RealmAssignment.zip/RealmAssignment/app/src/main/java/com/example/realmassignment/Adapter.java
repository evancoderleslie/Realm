package com.example.realmassignment;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import io.realm.RealmResults;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    private RealmResults<Student> realmResults;
    private Context mcontext;
    private int count;

    public Adapter(RealmResults<Student> students,Context context){
        realmResults=students;
        mcontext=context;
        count=0;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.activity_display,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Student student=realmResults.get(position);
        holder.name.setText(student.getName());
        holder.dept.setText(student.getDept());
        holder.phone.setText(String.valueOf(student.getPhone()));
        holder.roll.setText(String.valueOf(student.getRoll()));
        holder.gender.setText(student.getGender());

    }

    @Override
    public int getItemCount() {
        return realmResults.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView name;
        TextView phone;
        TextView roll;
        TextView dept;
        TextView gender;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            count++;
            name=itemView.findViewById(R.id.textView9);
            dept=itemView.findViewById(R.id.textView10);
            phone=itemView.findViewById(R.id.textView11);
            gender=itemView.findViewById(R.id.textView12);
            roll=itemView.findViewById(R.id.textView13);

        }
    }
}
